def addition(num1,num2):
    return num1+num2
def subtraction(num1,num2):
    return num1-num2
def multiply(num1,num2):
    return num1*num2
def divide(num1,num2):
    return num1/num2
print("select the opeartion : \n" \
      "1. Addition\n"
      "2.Subtract\n"
      "3.Multiplication\n"
      "4.Division\n")
operation = int(input("Enter the appropriate opeartion from 1, 2, 3, 4: "))
operand1 = float(input("enter the first operand : "))
operand2 = float(input("enter the second operand : "))
if operation == 1:
    print("operand1 + operand2 = ",addition(operand1,operand2))
elif operation == 2:
    print("operand1 - operand2 = ", subtraction(operand1,operand2))
elif operation == 3:
    print("operand1 x operand2 = ", multiply(operand1,operand2))
elif operation == 4:
    print("operand1 / operand2 = ", divide(operand1,operand2))
else:
    print("entered invalid operation")
      
        